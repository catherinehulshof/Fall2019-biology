graphics.off()

#Change Working Directory under "Misc"

# read in some data
# NB the column names have to be exactly, "group", "x", "y"
mydata <- read.table("file_name.txt",sep="\t",header=T)

# make the column names availble for direct calling
attach(mydata)

show(mydata)

# now loop through the data and calculate the ellipses
ngroups <- length(unique(group))



# split the isotope data based on group
spx <- split(x,group)
spy <- split(y,group)

# create some empty vectors for recording our metrics
SEA <- numeric(ngroups)
SEAc <- numeric(ngroups)

dev.new()
colorgroup = c(rep("input_color",length(which(group==1))))
			  
			
pchgroup = c(rep(16,length(which(group==1))))
			
		
plot(x,y,col=colorgroup,type="p",xlim=c(-25,-11),ylim=c(2,11),axes=F,pch=pchgroup
		, xlab = expression(~ delta ^"13"~'C')
		, ylab = expression(~ delta ^"15"~'N'))
box()
axis(1,at=seq(-25,-11,1),labels=F)
axis(1,at=seq(-25,-11,2),labels=T)
axis(2,at=seq(2,11,1),labels=F)
axis(2,at=seq(2,11,1),labels=T)

legend(-17.35, 11.5, c("Group_name"), lty = c(1,1), lwd= c(2.5,2.5,2.5), col = c('input_color'))

library(siar)


for (j in unique(group)){


  # Fit a standard ellipse to the data
  SE <- standard.ellipse(spx[[j]],spy[[j]],steps=1)
  
  # Extract the estimated SEA and SEAc from this object
  SEA[j] <- SE$SEA
  SEAc[j] <- SE$SEAc
  
  # plot the standard ellipse with d.f. = 2 (i.e. SEAc)
  # These are plotted here as thick solid lines



colorgroup = c('input_color')
  lines(SE$xSEAc,SE$ySEAc,lty=1,lwd=3,col=colorgroup[j])
}  
  
# print the area metrics to screen for comparison
# NB if you are working with real data rather than simulated then you wont be
# able to calculate the population SEA (pop.SEA)
# If you do this enough times or for enough groups you will easily see the
# bias in SEA as an estimate of pop.SEA as compared to SEAc which is unbiased.
# Both measures are equally variable.
print(cbind(SEA,SEAc))



