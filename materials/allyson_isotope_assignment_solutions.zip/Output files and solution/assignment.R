#so first off, we need to install the package SIAR in R and then read in the library

library(siar)

#next we will read in the datasheets for the data. The first datasheet we need to read in is the raw isotope data for the grasshoppers. The next datasheet is the source data. This datasheet has means and standard deviations for the different potential diet groups. The final datasheet has trophic discrimination factors and standard deviations for those. 

data<-read.table("grasshopper_two_species.txt",sep="\t",header=TRUE) 
sources<-read.table("source_four_groups.txt",sep="\t", header=TRUE) 
tef<-read.table("tef_four_groups.txt",sep="\t", header=TRUE)

#The next thing we need to do is run the mixing model. The model assumes that each target value comes from a Gaussian distribution with an unknown mean and standard deviation. The structure of the mean is a weighted combination of the food sources' isotopic values. The weights are made up dietary proportions (which are given a Dirichlet prior distribution) and the concentration depdendencies given for the different food sources. The standard deviation is divided up between the uncertainty around the fractionation corrections (if corrections are given) and the natural variability between target individuals within a defined group (or between all individuals if no grouping structure is specified). 


# The inputs for the model are first, the data, then the dietary sources, and the the trophic enrichment factors. We also need to tell SIAR that we have no data on concentration dependence (concdep=0). The final two numbers are the number of iterations for the model to run, and the number of initial iterations to discard)

model1<-siarmcmcdirichletv4(data,sources,tef,concdep=0,500,50)

#This will produce a biplot with the isotope that is in the first column on the x-axis, and the isotope in the second column on the y-axis. 
siarplotdata(model1)

#lets create an object for the output of the model
out<-model1$output

#lets go ahead and look at the output dataframe to see what we are working with
View(out)


#I am going to go ahead and create an output file for this data
write.table(out,file="two_grasshopper.output.csv", sep= ",")

#So, the next step is a little weird, the way that this program's output is set up, the column titles are shifted one cell to the left. So we will just add a cell here, and then re-read the resulting spreadsheet back into R. I tried to figure out a way to do this in R and was unsuccessful. 
output_file <- read.csv("two_grasshopper.output.csv")

#The outputs from the model are a column of iterations of running the mixing model. Each cell represents a proportion of a particular dietary item calculated by the model. We want to get the average values for these columns of proportions, so we will take the average of the column for each different dietary source. We will go ahead and ignore the standard deviations calculated by the model. 

#colMeans is a quick and easy way to check all of the means for our columns

colMeans(out)

#SIAR has a nice shortcut function that will plot these mean the proportions of different sources for us. To compare the proportions of each source for a group:

siarproportionbygroupplot(model1)

#let's reorder the dataframe to input into our SIBER file
library(dplyr)
?rename
rename_gs <- rename(data, group = Group, y = chitin.d15N, x = chitin.d13C)
rename_gs

reorder <- rename_gs[c("group", "x", "y")]
reorder
write.table(rename_gs,file="SIBER_2.txt", sep= ",")

#This starts the SIBER code. On a Mac you need to run this section of code in R rather than R Studio. 

# read in some data
# NB the column names have to be exactly, "group", "x", "y"
mydata <- read.table("SIBER_2.txt",sep=",",header=T)
head(mydata)

# make the column names available for direct calling. This basically means that the datasheet that you apply this function to will be called automatically, and you wont need to specify where youre data is coming from. 
attach(mydata)

show(mydata)

# now loop through the data and calculate the ellipses. Unique is acting on all of the groups in the datasheet to return a vector with all duplicates removed. So it will give an output of 1 through 8 because we have 8 unique groups. Length will then count the number of unique groups
ngroups <- length(unique(group))
ngroups


# split the isotope data based on group. the split function divides the data in groups as defined by group. So basically these functions make vectors of the x column and y column of the data
spx <- split(x,group)
spy <- split(y,group)

# create some empty vectors for recording our metrics
SEA <- numeric(ngroups)
SEAc <- numeric(ngroups)

#dev.new allows a graphical device to be opened. A graphical devide is any kind of format that R uses to produce images. 
dev.new()


#ok, so this is a lot, so let's break this next part down. the function 'which' indicates which group we are interested in looking at. If group==1, we are interested in the values for group 1. We are taking the length for values in group 1. the function rep replicates values in x for all values after the comma. So, we are effectively telling R that we want to make all of the 3 values for group 1 a specific color. And we are applying this same function for all of the different groups with different colors and saving it as a vector. 
length(which(group==1))

colorgroup = c(rep("paleturquoise",length(which(group==1)))
               ,rep("yellow2",length(which(group==2))))
#This next code is doing the same thing, but telling R the shape of the points to plot. It is kind of redundant. 

pchgroup = c(rep(16,length(which(group==1)))
             ,rep(16,length(which(group==2))))

#here we are setting up our graph. First, we tell R to plot x and y with the color set to be the colorgroup vector we created earlier. We set the type of object to be plotted to be p, which represents points in a scatterplot. Next, the functions xlim and y lim set the minimum and maximum values that our points can be. In this case, xlim is set to be the min and max values for carbon isotope values, and ylim is set to be the min and max values for nitrogen isotope values. Next we set the axes equal to false, so that this graph does not have axes. This gives the user more control over the axes later on. Pch is the type of shape to use in the scatterplot. We set it to equal the pchgroup vector we created earlier, so that all of the pches are the same. 
#Next we use the function box to draw a box around our plot. Because we set the axes to equal false earlier, we will add the axes to our plot now. The first input for the axis function is the side of the graph, with 1=below, 2=left, 3=above and 4=right. The at argument specifies where the tick marks on the axis will be made. We are telling R that we want tick marks to be made between the range specified and then we tell it how frequently we want a tick mark made, so for each discrete integer between -25 and -11 in this case. If I dont want a label at every tick mark, I tell the function that labels equals false. Then I add a duplicate line of the same code to tell R how frequently to make the labels. In this case, I want an x label every other tick mark, so I will set labels to true and add one every two integers. 

plot(x,y,col=colorgroup,type="p",xlim=c(-25,-11),ylim=c(2,11),axes=F,pch=pchgroup
     , xlab = expression(~ delta ^"13"~'C')
     , ylab = expression(~ delta ^"15"~'N'))
box()
axis(1,at=seq(-25,-11,1),labels=F)
axis(1,at=seq(-25,-11,2),labels=T)
axis(2,at=seq(2,11,1),labels=F)
axis(2,at=seq(2,11,1),labels=T)

#Next we will create the legend for our graph. We start out by telling R where to put the legend in terms of coordinates. Then, we will add the species names for all of our grasshopper groups, in order. lty specifies the line type. We are telling R that we want a solid line plotted both in the horizontal and vertical directions. lwd is the line width. We are telling R that we want all of the lines in the legend to be a particular size. Finally, we tell R the colors of our grasshopper species by setting color equal to a vector of all of the colors of our species in order. 

legend(-17.35, 11.5, c("Arphia conspirsa","Melanoplus arizonae"), lty = c(1,1), lwd= c(2.5,2.5,2.5), col = c('paleturquoise','yellow2'))

#ok, lets read in the siar package again. 
library(siar)

#and lets use a for loop. For each iteration of a unique species, we tell R to fit a standard ellipse to the data, using the x vector we made earlier and the y vector we made earlier. For steps, the higher the number, the more angular the ellipse will appear. 

for (j in unique(group)){
  
  
  # Fit a standard ellipse to the data
  SE <- standard.ellipse(spx[[j]],spy[[j]],steps=1)
  
  #Next, we want to calculate the area of the ellipses we just created. We set the dataframes we created earlier to be equal to the standard ellipses we just calculated. 
  
  # Extract the estimated SEA and SEAc from this object
  SEA[j] <- SE$SEA
  SEAc[j] <- SE$SEAc
  
  # plot the standard ellipse with d.f. = 2 (i.e. SEAc)
  # These are plotted here as thick solid lines
  
  #We then set the colors to be equal to the same color vector we made earlier, and then tell R to add connected line segments to our plot, to create the ellipses. 
  
  colorgroup = c('paleturquoise','yellow2')
  lines(SE$xSEAc,SE$ySEAc,lty=1,lwd=3,col=colorgroup[j])
}  

