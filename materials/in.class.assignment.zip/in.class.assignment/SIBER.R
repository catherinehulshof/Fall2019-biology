
# read in some data
# NB the column names have to be exactly, "group", "x", "y"
mydata <- read.table("boer.siber.txt",sep="\t",header=T)

# make the column names available for direct calling. This basically means that the datasheet that you apply this function to will be called automatically, and you wont need to specify where youre data is coming from. 
attach(mydata)

show(mydata)

# now loop through the data and calculate the ellipses. Unique is acting on all of the groups in the datasheet to return a vector with all duplicates removed. So it will give an output of 1 through 8 because we have 8 unique groups. Length will then count the number of unique groups
ngroups <- length(unique(group))
ngroups


# split the isotope data based on group. the split function divides the data in groups as defined by group. So basically these functions make vectors of the x column and y column of the data
spx <- split(x,group)
spy <- split(y,group)

spx

# create some empty vectors for recording our metrics
SEA <- numeric(ngroups)
SEAc <- numeric(ngroups)

#dev.new allows a graphical device to be opened. A graphical devide is any kind of format that R uses to produce images. I dont honestly understand it that well. 
dev.new()

?rep

#ok, so this is a lot, so let's break this next part down. the function 'which' indicates which group we are interested in looking at. If group==1, we are interested in the values for group 1. We are taking the length for values in group 1. the function rep replicates values in x for all values after the comma. So, we are effectively telling R that we want to make all of the 3 values for group 1 a specific color. And we are applying this same function for all of the different groups with different colors and saving it as a vector. 
length(which(group==1))

colorgroup = c(rep("paleturquoise",length(which(group==1)))
               ,rep("yellow2",length(which(group==2)))
               ,rep("royalblue3",length(which(group==3)))
               ,rep("goldenrod",length(which(group==4)))
               ,rep("blueviolet",length(which(group==5)))
               ,rep("firebrick3", length(which(group==6)))
               ,rep("sienna1", length(which(group==7))))
#This next code is doing the same thing, but telling R the shape of the points to plot. It is kind of redundant. 

pchgroup = c(rep(16,length(which(group==1)))
             ,rep(16,length(which(group==2)))
             ,rep(16,length(which(group==3)))
             ,rep(16,length(which(group==4)))
             ,rep(16,length(which(group==5)))
             ,rep(16,length(which(group==6)))
             ,rep(16,length(which(group==7))))

#here we are setting up our graph. First, we tell R to plot x and y with the color set to be the colorgroup vector we created earlier. We set the type of object to be plotted to be p, which represents points in a scatterplot. Next, the functions xlim and y lim set the minimum and maximum values that our points can be. In this case, xlim is set to be the min and max values for carbon isotope values, and ylim is set to be the min and max values for nitrogen isotope values. Next we set the axes equal to false, so that this graph does not have axes. This gives the user more control over the axes later on. Pch is the type of shape to use in the scatterplot. We set it to equal the pchgroup vector we created earlier, so that all of the pches are the same. 
#Next we use the function box to draw a box around our plot. Because we set the axes to equal false earlier, we will add the axes to our plot now. The first input for the axis function is the side of the graph, with 1=below, 2=left, 3=above and 4=right. The at argument specifies where the tick marks on the axis will be made. We are telling R that we want tick marks to be made between the range specified and then we tell it how frequently we want a tick mark made, so for each discrete integer between -25 and -11 in this case. If I dont want a label at every tick mark, I tell the function that labels equals false. Then I add a duplicate line of the same code to tell R how frequently to make the labels. In this case, I want an x label every other tick mark, so I will set labels to true and add one every two integers. 
?axis
plot(x,y,col=colorgroup,type="p",xlim=c(-25,-11),ylim=c(2,11),axes=F,pch=pchgroup
     , xlab = expression(~ delta ^"13"~'C')
     , ylab = expression(~ delta ^"15"~'N'))
box()
axis(1,at=seq(-25,-11,1),labels=F)
axis(1,at=seq(-25,-11,2),labels=T)
axis(2,at=seq(2,11,1),labels=F)
axis(2,at=seq(2,11,1),labels=T)

#Next we will create the legend for our graph. We start out by telling R where to put the legend in terms of coordinates. Then, we will add the species names for all of our grasshopper groups, in order. lty specifies the line type. We are telling R that we want a solid line plotted both in the horizontal and vertical directions. lwd is the line width. We are telling R that we want all of the lines in the legend to be a particular size. Finally, we tell R the colors of our grasshopper species by setting color equal to a vector of all of the colors of our species in order. 

legend(-17.35, 11.5, c("Melanoplus arizonai","Xanthippus corallipes", "Psoloessa delicatula", "Aulocara femoratum", "Melanoplus gladstonii", "Trimerotropis pallidipenis", "Arphia pseudonietana"), lty = c(1,1), lwd= c(2.5,2.5,2.5), col = c('paleturquoise','yellow2','royalblue3','goldenrod','blueviolet', 'firebrick3','sienna1'))

#ok, lets read in the siar package again. 
library(siar)

#and lets use a for loop. For each iteration of a unique species, we tell R to fit a standard ellipse to the data, using the x vector we made earlier and the y vector we made earlier. For steps, the higher the number, the more angular the ellipse will appear. 

for (j in unique(group)){
  
  
  # Fit a standard ellipse to the data
  SE <- standard.ellipse(spx[[j]],spy[[j]],steps=1)
  
  #Next, we want to calculate the area of the ellipses we just created. We set the dataframes we created earlier to be equal to the standard ellipses we just calculated. 
  
  # Extract the estimated SEA and SEAc from this object
  SEA[j] <- SE$SEA
  SEAc[j] <- SE$SEAc
  
  # plot the standard ellipse with d.f. = 2 (i.e. SEAc)
  # These are plotted here as thick solid lines
  
  #We then set the colors to be equal to the same color vector we made earlier, and then tell R to add connected line segments to our plot, to create the ellipses. 
  
?lines  
  colorgroup = c('paleturquoise','yellow2','royalblue3','goldenrod','blueviolet','firebrick3','sienna1')
  lines(SE$xSEAc,SE$ySEAc,lty=1,lwd=3,col=colorgroup[j])
}  
