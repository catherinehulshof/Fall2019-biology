#so first off, we need to install the package SIAR in R and then read in the library

install.packages("siar")
library(siar)

#next we will read in the datasheets for the data. The first datasheet we need to read in is the raw isotope data for the grasshoppers. The next datasheet is the source data. This datasheet has means and standard deviations for the different potential diet groups. The final datasheet has trophic discrimination factors and standard deviations for those. 

data<-read.table("in.class.assignment/grasshopper_one_species.txt",sep="\t",header=TRUE) 
sources<-read.table("in.class.assignment/source_two_groups.txt",sep="\t", header=TRUE) 
tef<-read.table("in.class.assignment/tef_two_groups.txt",sep="\t", header=TRUE)

#The next thing we need to do is run the mixing model. The model runs a bunch of iterations that generate independent samples or proportion estimates for your data based on the diet sources you provide. 


# The inputs for the model are first, the data, then the dietary sources, and the the trophic enrichment factors. We also need to tell SIAR that we have no data on concentration dependence (concdep=0). The final two numbers are the number of iterations for the model to run, and the number of initial iterations to discard)

model1<-siarmcmcdirichletv4(data,sources,tef,concdep=0,500,50)

#This will produce a biplot with the isotope that is in the first column on the x-axis, and the isotope in the second column on the y-axis. 
siarplotdata(model1)

#lets create an object for the output of the model
out<-model1$output

#lets go ahead and look at the output dataframe to see what we are working with
View(out)


#I am going to go ahead and create an output file for this data
write.table(out,file="one_grasshopper.output.csv", sep= ",")

#So, the next step is a little weird, the way that this program's output is set up, the column titles are shifted one cell to the left. So we will just add a cell here, and then re-read the resulting spreadsheet back into R. I tried to figure out a way to do this in R and was unsuccessful. 
output_file <- read.csv("one_grasshopper.output.csv")

#The outputs from the model are a column of iterations of running the mixing model. Each cell represents a proportion of a particular dietary item calculated by the model. We want to get the average values for these columns of proportions, so we will take the average of the column for each different dietary source. We will go ahead and ignore the standard deviations calculated by the model. 

C4_grass_mean <- mean(output_file$C4._Grass)
print(C4_grass_mean)

C3_mean <- mean(output_file$C3_Annual.Perennial)
print(C3_mean)

#SIAR has a nice shortcut function that will plot these mean the proportions of different sources for us. To compare the proportions of each source for a group:

siarproportionbygroupplot(model1)
